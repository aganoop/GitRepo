var http = require('http');
var port = 7000;

var server = http.createServer(function(req, res) {
    return makeHTMLFile(res);
});

function makeHTMLFile(res) {
    res.writeHeader(200, { "Content-Type": "text/html" });
    res.write('<html><head></head><body><div></input><h1>Hi Abin</h1></div></body></html>');
    res.end();
}

server.on('listening', function() {
    console.log('Server is running on ' + port + ' port.');
});

server.listen(port);